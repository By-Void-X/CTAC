#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${OUTPUT_DIR:=$PWD/release}"
mkdir -p "$OUTPUT_DIR"
python3 - "$OUTPUT_DIR" <<'PY'
from pathlib import Path
import json,sys,zipfile
out=Path(sys.argv[1]); data=json.loads(Path('manifest.json').read_text()); so=Path('build')/data['entry']
if not so.is_file() or so.read_bytes()[:4]!=b'\x7fELF': raise SystemExit('Build first: required ELF binary missing')
assert data['version']=='1.4.8', 'Unexpected manifest version'
assert data['minecraft_versions']==['1.26.*','1.26.5*']
with zipfile.ZipFile(out/f"libCheatlessTweaksAllCommands_{data['version']}.levipack",'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.write('manifest.json','manifest.json');z.write(so,data['entry'])
 for p in sorted(Path('resources').rglob('*')):
  if p.is_file():z.write(p,p.as_posix())
print('Packaged', data['entry'])
PY
