# Cheatless Tweaks All Commands v1.4.8

Native LeviLauncher/LeviLaunchroid `preload-native` mod for Minecraft Bedrock Android **1.26.52.3** (arm64-v8a). Maintains the manifest compatibility array `["1.26.*","1.26.5*"]`.

## New in v1.4.8

Preserves native enum-constraint flags in the optional autocomplete hook instead of clearing the low three bits. Intended to restore vanilla enum/intellisense metadata for arguments such as `/give @s <block>`; must be verified in-game.


Fixes the skipped registration of the built-in `/ability` command in non-Education worlds by validating and NOP-patching the actual Education command-dispatch branch at RVA `0x0EC07A28`. See `docs/CheatlessTweaksAllCommands_1.4.8_Update_Report.txt` for the original AArch64 opcode, wildcard signature, and offline evidence.

## Rebuild

Prerequisites: Android NDK r28c, the **supplied v1.5.27** `libpreloader.so`, and Bash. In this directory:

```sh
ANDROID_NDK_HOME=/path/to/android-ndk-r28c \
PRELOADER_DIR=/path/to/dir-containing-libpreloader.so \
bash build_android.sh
```

The resulting shared object is `build/libcheatless_tweaks_all_commands_v1_4_8.so`. The release `.levipack` is a ZIP archive of `manifest.json`, the root-level `.so`, and `resources/`.

## Runtime notes

Install the native mod before opening a world. Tested offline only, not on a real device. Each code-address modification validates the exact original bytes and reverts only its own still-matching patches. The Minecraft offsets are pinned to the uploaded libminecraftpe.so, rather than all wildcard-listed patch versions. Logcat tag: `CTAC148`.
