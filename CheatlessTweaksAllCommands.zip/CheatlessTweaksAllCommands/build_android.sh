#!/usr/bin/env bash
set -euo pipefail
: "${ANDROID_NDK_HOME:?set ANDROID_NDK_HOME to android-ndk-r28c}"
: "${PRELOADER_DIR:?set PRELOADER_DIR to the directory containing libpreloader.so}"
BIN="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin"
CLANG="$BIN/clang++"
if [[ ! -x "$CLANG" ]]; then CLANG="$BIN/clang-19"; fi
if [[ ! -x "$CLANG" ]]; then echo "clang is not executable in $BIN" >&2; exit 1; fi
mkdir -p build
rm -f build/libcheatless_tweaks_all_commands_v1_4_8.so
"$CLANG" --driver-mode=g++ --target=aarch64-linux-android28 \
  -shared -fPIC -std=c++20 -O2 -fvisibility=hidden -fno-exceptions -fno-rtti \
  src/main.cpp \
  -L"$PRELOADER_DIR" -Wl,--no-as-needed -lpreloader -Wl,--as-needed \
  -llog -ldl -lm \
  -Wl,-soname,libcheatless_tweaks_all_commands_v1_4_8.so \
  -Wl,-z,max-page-size=16384 -Wl,--build-id=sha1 -Wl,--no-undefined \
  -o build/libcheatless_tweaks_all_commands_v1_4_8.so
