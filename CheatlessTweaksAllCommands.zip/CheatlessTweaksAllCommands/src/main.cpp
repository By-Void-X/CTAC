#include <android/log.h>
#include <cstddef>
#include <cstdint>
#include <cstring>

#define CTAC_EXPORT extern "C" __attribute__((visibility("default")))

extern "C" {
using GHook = void*;
GHook GlossHook(void* target, void* replacement, void** original);
void GlossHookDelete(GHook hook);
void* ReadMemory(void* address, void* buffer, std::size_t size, bool changeProtection);
void WriteMemory(void* address, const void* data, std::size_t size, bool changeProtection);
uintptr_t GlossGetLibBias(const char* libraryName);
uintptr_t GlossFindLibMapping(const char* libraryName, int pid, char* pathOut, std::size_t* mappedSizeOut);
}

namespace pl::mod {
struct ModContext;
using LifecycleFunction = bool (*)(void*, ModContext&);
struct ModRegistration {
    void* instance;
    LifecycleFunction load;
    LifecycleFunction enable;
    LifecycleFunction disable;
    LifecycleFunction unload;
};
}

namespace {
constexpr const char* TAG = "CTAC148";
constexpr const char* MC_LIB = "libminecraftpe.so";
constexpr uint32_t NOP = 0xD503201Fu;

__attribute__((section(".ctac.version"), used, visibility("default")))
const char kBuildIdentity[] =
    "CheatlessTweaksAllCommands V1.4.8 | MCBE 1.26.52.03 | "
    "Levi Launchroid 1.5.27 ABI | arm64-v8a | clean-source-core-first";

enum StatusBits : uint32_t {
    STATUS_LOADED          = 1u << 0,
    STATUS_MC_BASE         = 1u << 1,
    STATUS_CORE_VALIDATED  = 1u << 2,
    STATUS_REGISTER_HOOK   = 1u << 3,
    STATUS_EXPAND_HOOK     = 1u << 4,
    STATUS_ORIGIN_HOOK     = 1u << 5,
    STATUS_OVERLOAD_HOOK   = 1u << 6,
    STATUS_CONSTRAINT_HOOK = 1u << 7,
    STATUS_GATE_A          = 1u << 8,
    STATUS_GATE_B          = 1u << 9,
    STATUS_DISPATCH_GATE   = 1u << 10,
    STATUS_ENUM_HOOK       = 1u << 11,
    STATUS_CHAT_HOOK       = 1u << 12,
    STATUS_OPTIONAL        = 1u << 13,
    STATUS_ABILITY_GATE   = 1u << 14,
    STATUS_ENABLED         = 1u << 31,
};

struct HookState {
    GHook handle{};
    void* original{};
    bool owned{};
};

struct PatchState {
    const char* name;
    uintptr_t rva;
    uint8_t expected[8];
    uint8_t replacement[8];
    uint8_t length;
    bool critical;
    bool applied;
    bool owned;
};

struct RuntimeState {
    uintptr_t base{};
    uint32_t status{};
    bool coreInstalled{};
    bool optionalAttempted{};
    HookState registerHook{};
    HookState enumConstraintHook{};
    HookState expansionHook{};
    HookState originHook{};
    HookState overloadHook{};
    HookState constraintSetHook{};
    HookState chatHook{};
};

RuntimeState g{};

static void logi(const char* msg) { __android_log_print(ANDROID_LOG_INFO, TAG, "%s", msg); }
static void logw(const char* msg) { __android_log_print(ANDROID_LOG_WARN, TAG, "%s", msg); }
static void loge(const char* msg) { __android_log_print(ANDROID_LOG_ERROR, TAG, "%s", msg); }
static void logAddr(const char* stage, uintptr_t addr) {
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s @ 0x%llx", stage,
                        static_cast<unsigned long long>(addr));
}

static bool readBytes(uintptr_t address, void* out, std::size_t len) {
    return ReadMemory(reinterpret_cast<void*>(address), out, len, true) != nullptr;
}

static bool bytesEqual(uintptr_t address, const uint8_t* expected, std::size_t len) {
    uint8_t current[64]{};
    if (len > sizeof(current) || !readBytes(address, current, len)) return false;
    return std::memcmp(current, expected, len) == 0;
}

static bool getMinecraftBase() {
    if (g.base) return true;
    g.base = GlossGetLibBias(MC_LIB);
    if (!g.base) {
        std::size_t mapped = 0;
        g.base = GlossFindLibMapping(MC_LIB, -1, nullptr, &mapped);
    }
    if (!g.base) {
        loge("minecraft base unavailable; core install deferred/failed");
        return false;
    }
    g.status |= STATUS_MC_BASE;
    logAddr("libminecraftpe base", g.base);
    return true;
}

// Exact 1.26.52.03 hook prologue anchors.
static const uint8_t SIG_REGISTER[16] = {
    0xFD,0x7B,0xBA,0xA9,0xFC,0x6F,0x01,0xA9,0xFA,0x67,0x02,0xA9,0xF8,0x5F,0x03,0xA9};
static const uint8_t SIG_ENUM_CONSTRAINT[16] = {
    0xFF,0x43,0x03,0xD1,0xFD,0x7B,0x07,0xA9,0xFC,0x6F,0x08,0xA9,0xFA,0x67,0x09,0xA9};
static const uint8_t SIG_EXPANSION[16] = {
    0xFD,0x7B,0xBE,0xA9,0xF4,0x4F,0x01,0xA9,0xFD,0x03,0x00,0x91,0x28,0x00,0x40,0xF9};
static const uint8_t SIG_ORIGIN[16] = {
    0xFF,0x83,0x01,0xD1,0xFD,0x7B,0x02,0xA9,0xF8,0x5F,0x03,0xA9,0xF6,0x57,0x04,0xA9};
static const uint8_t SIG_OVERLOAD[16] = {
    0xFF,0x03,0x02,0xD1,0xFD,0x7B,0x02,0xA9,0xFC,0x6F,0x03,0xA9,0xFA,0x67,0x04,0xA9};
static const uint8_t SIG_CONSTRAINT_SET[16] = {
    0x09,0x28,0x41,0xF9,0x29,0x08,0x00,0xB4,0xFD,0x7B,0xBC,0xA9,0xF7,0x0B,0x00,0xF9};
static const uint8_t SIG_CHAT[16] = {
    0x00,0x04,0x40,0xF9,0x08,0x00,0x40,0xF9,0x01,0x0D,0x40,0xF9,0x20,0x00,0x1F,0xD6};

constexpr uintptr_t RVA_REGISTER       = 0x0EBDB6FC;
constexpr uintptr_t RVA_ENUM_CONSTRAINT= 0x0EBDC774;
constexpr uintptr_t RVA_EXPANSION      = 0x0EBF5BA8;
constexpr uintptr_t RVA_ORIGIN         = 0x0EBE7598;
constexpr uintptr_t RVA_OVERLOAD       = 0x0EBEE024;
constexpr uintptr_t RVA_CONSTRAINT_SET = 0x0EBEE3EC;
constexpr uintptr_t RVA_CHAT           = 0x09A56148;
constexpr uintptr_t RVA_ABILITY_DISPATCH = 0x0EC07A28;

// Hardcoded 1.26.52.03 AbilityCommand::setup registration dispatch anchor.
// Wildcards cover BL displacements; the mutable branch is canonicalized below.
// Scanned offline: exactly one .text match in the supplied libminecraftpe.so.
static const uint8_t SIG_ABILITY_DISPATCH[32] = {
    0x28,0x03,0x40,0xF9, 0xE0,0x03,0x19,0xAA,
    0x08,0xB5,0x42,0xF9, 0x00,0x01,0x3F,0xD6,
    0x00,0x00,0x00,0x94, 0xC0,0x02,0x00,0x36,
    0xE0,0x03,0x15,0xAA, 0x00,0x00,0x00,0x97
};
static const uint8_t MASK_ABILITY_DISPATCH[32] = {
    0xFF,0xFF,0xFF,0xFF, 0xFF,0xFF,0xFF,0xFF,
    0xFF,0xFF,0xFF,0xFF, 0xFF,0xFF,0xFF,0xFF,
    0x00,0x00,0x00,0xFF, 0xFF,0xFF,0xFF,0xFF,
    0xFF,0xFF,0xFF,0xFF, 0x00,0x00,0x00,0xFF
};

static bool verifyAbilityDispatchSignature() {
    uint8_t current[sizeof(SIG_ABILITY_DISPATCH)]{};
    const uintptr_t anchor = g.base + RVA_ABILITY_DISPATCH - 20;
    if (!readBytes(anchor, current, sizeof(current))) return false;
    const uint8_t originalBranch[] = {0xC0,0x02,0x00,0x36};
    const uint8_t patchedBranch[]  = {0x1F,0x20,0x03,0xD5};
    if (std::memcmp(current + 20, originalBranch, 4) == 0) {
        // Already in the canonical, unmodified form.
    } else if (std::memcmp(current + 20, patchedBranch, 4) == 0) {
        std::memcpy(current + 20, originalBranch, 4);
    } else {
        return false;
    }
    for (std::size_t i = 0; i < sizeof(current); ++i) {
        if (((current[i] ^ SIG_ABILITY_DISPATCH[i]) & MASK_ABILITY_DISPATCH[i]) != 0)
            return false;
    }
    return true;
}

using RegisterCommandFn = uintptr_t (*)(void*, void*, void*, uint8_t, uint16_t, uint16_t);
using EnumConstraintFn = uintptr_t (*)(void*, void*, void*, uint8_t);
using ExpansionFn = bool (*)(void*, void*);
using OriginFn = bool (*)(void*, void*, void*);
using OverloadFn = bool (*)(void*, void*, void*);
using ConstraintSetFn = bool (*)(void*, uint32_t, void*, uint32_t);
using ChatFn = uint32_t (*)(void*);

static RegisterCommandFn origRegister{};
static EnumConstraintFn origEnumConstraint{};
static ChatFn origChat{};

static uint16_t normalizeCommandFlags(uint16_t value) {
    return static_cast<uint16_t>((value & 0xFDDBu) | 0x0080u);
}

static uintptr_t hookRegisterCommand(void* self, void* name, void* description,
                                     uint8_t /*permission*/, uint16_t flagsA, uint16_t flagsB) {
    return origRegister
        ? origRegister(self, name, description, 0,
                       normalizeCommandFlags(flagsA), normalizeCommandFlags(flagsB))
        : 0;
}

// Preserve the original enum-constraint flags. Stripping the low three bits
// can interfere with native enum/intellisense metadata (e.g. /give block/item
// suggestions). The command authorization bypass is handled separately.
static uintptr_t hookEnumConstraints(void* self, void* a, void* b, uint8_t flags) {
    return origEnumConstraint ? origEnumConstraint(self, a, b, flags) : 0;
}

static bool hookExpansionAllowed(void*, void*) { return true; }
static bool hookOriginCanRun(void*, void*, void*) { return true; }
static bool hookOriginCanRunOverload(void*, void*, void*) { return true; }
static bool hookMatchesConstraintSet(void*, uint32_t, void*, uint32_t) { return true; }
static uint32_t hookChatDirty(void* self) { return (origChat ? origChat(self) : 0u) | 0x7u; }

static bool installHook(HookState& state, uintptr_t rva, const uint8_t* prologue,
                        std::size_t prologueLen, void* replacement, void** originalOut,
                        const char* name, bool critical) {
    if (state.handle) return true;
    const uintptr_t target = g.base + rva;
    if (!bytesEqual(target, prologue, prologueLen)) {
        __android_log_print(critical ? ANDROID_LOG_ERROR : ANDROID_LOG_WARN, TAG,
                            "%s: target prologue mismatch at RVA 0x%llx", name,
                            static_cast<unsigned long long>(rva));
        return false;
    }
    void* original = nullptr;
    GHook h = GlossHook(reinterpret_cast<void*>(target), replacement, &original);
    if (!h || !original) {
        __android_log_print(critical ? ANDROID_LOG_ERROR : ANDROID_LOG_WARN, TAG,
                            "%s: GlossHook failed at RVA 0x%llx", name,
                            static_cast<unsigned long long>(rva));
        if (h) GlossHookDelete(h);
        return false;
    }
    state.handle = h;
    state.original = original;
    state.owned = true;
    if (originalOut) *originalOut = original;
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s: hook installed RVA 0x%llx", name,
                        static_cast<unsigned long long>(rva));
    return true;
}

static PatchState patches[] = {
    {"top-level authorization gate A", 0x0EBFC364,
     {0x5D,0x01,0x00,0x14}, {0x28,0x00,0x00,0x14}, 4, true, false, false},
    {"top-level authorization gate B", 0x0EBFC400,
     {0xC8,0x26,0x00,0x36}, {0x1F,0x20,0x03,0xD5}, 4, true, false, false},
    {"lower generic-disabled dispatcher gate", 0x0EC57278,
     {0x60,0x11,0x00,0x36}, {0x1F,0x20,0x03,0xD5}, 4, true, false, false},
    // ec07a28: tbz w0, #0, ec07a80 (skips AbilityCommand::setup).
    // NOP makes the already-present Education command registration block run
    // regardless of the Education-mode predicate. No duplicate registration:
    // the block branches over its alternative path at ec07a7c.
    {"Education command registration including /ability", RVA_ABILITY_DISPATCH,
     {0xC0,0x02,0x00,0x36}, {0x1F,0x20,0x03,0xD5}, 4, true, false, false},

    {"integrated EDU registration gate", 0x10868794,
     {0x40,0x4A,0x00,0x36}, {0x1F,0x20,0x03,0xD5}, 4, false, false, false},
    {"Education client command gate", 0x08561318,
     {0x20,0x01,0x00,0x36}, {0x1F,0x20,0x03,0xD5}, 4, false, false, false},
    {"CodeCommand registration gate", 0x08561320,
     {0x60,0x00,0x00,0x36}, {0x1F,0x20,0x03,0xD5}, 4, false, false, false},
    {"ClassRoomModeCommand registration gate", 0x08561330,
     {0x60,0x00,0x00,0x54}, {0x1F,0x20,0x03,0xD5}, 4, false, false, false},
    {"Ability hidden-enum filter", 0x10864730,
     {0x20,0xFF,0x07,0x36}, {0x1F,0x20,0x03,0xD5}, 4, false, false, false},
    {"GameRule requires-cheats gate A", 0x0EB899DC,
     {0xC0,0x00,0x00,0x36}, {0x06,0x00,0x00,0x14}, 4, false, false, false},
    {"GameRule requires-cheats gate B", 0x0EB89C48,
     {0xC0,0x00,0x00,0x36}, {0x06,0x00,0x00,0x14}, 4, false, false, false},
    {"GameRule requires-cheats gate C", 0x0EB89D84,
     {0xC0,0x00,0x00,0x36}, {0x06,0x00,0x00,0x14}, 4, false, false, false},
    {"ServerPlayer Hardcore gamemode gate", 0x0EC4C1EC,
     {0xE0,0x09,0x00,0x36}, {0x1F,0x20,0x03,0xD5}, 4, false, false, false},
    {"LocalPlayer Hardcore gamemode gate", 0x0AAD0114,
     {0xC0,0x03,0x00,0x36}, {0x1F,0x20,0x03,0xD5}, 4, false, false, false},
    {"Legacy Hardcore UI predicate", 0x09DB2B94,
     {0xE0,0x03,0x1F,0x2A}, {0x20,0x00,0x80,0x52}, 4, false, false, false},
    {"Realms Hardcore UI predicate", 0x0A3F54F4,
     {0x08,0x04,0x40,0xF9,0x09,0xA1,0x6F,0x39},
     {0x20,0x00,0x80,0x52,0xC0,0x03,0x5F,0xD6}, 8, false, false, false},
};

static bool applyPatch(PatchState& p) {
    if (p.applied) return true;
    const uintptr_t address = g.base + p.rva;
    uint8_t current[8]{};
    if (!readBytes(address, current, p.length)) {
        __android_log_print(p.critical ? ANDROID_LOG_ERROR : ANDROID_LOG_WARN, TAG,
                            "%s: ReadMemory failed", p.name);
        return false;
    }
    if (std::memcmp(current, p.replacement, p.length) == 0) {
        p.applied = true;
        p.owned = false;
        __android_log_print(ANDROID_LOG_INFO, TAG, "%s: already patched", p.name);
        return true;
    }
    if (std::memcmp(current, p.expected, p.length) != 0) {
        __android_log_print(p.critical ? ANDROID_LOG_ERROR : ANDROID_LOG_WARN, TAG,
                            "%s: original-byte mismatch at RVA 0x%llx", p.name,
                            static_cast<unsigned long long>(p.rva));
        return false;
    }
    WriteMemory(reinterpret_cast<void*>(address), p.replacement, p.length, true);
    uint8_t verify[8]{};
    if (!readBytes(address, verify, p.length) || std::memcmp(verify, p.replacement, p.length) != 0) {
        __android_log_print(p.critical ? ANDROID_LOG_ERROR : ANDROID_LOG_WARN, TAG,
                            "%s: post-write verification failed", p.name);
        return false;
    }
    p.applied = true;
    p.owned = true;
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s: patch installed RVA 0x%llx", p.name,
                        static_cast<unsigned long long>(p.rva));
    return true;
}

static void revertPatch(PatchState& p) {
    if (!p.applied) return;
    if (p.owned && g.base) {
        const uintptr_t address = g.base + p.rva;
        uint8_t current[8]{};
        if (readBytes(address, current, p.length) &&
            std::memcmp(current, p.replacement, p.length) == 0) {
            WriteMemory(reinterpret_cast<void*>(address), p.expected, p.length, true);
        }
    }
    p.applied = false;
    p.owned = false;
}

static void uninstallHook(HookState& h) {
    if (h.handle && h.owned) GlossHookDelete(h.handle);
    h = {};
}

static void rollbackAll() {
    for (std::size_t i = sizeof(patches)/sizeof(patches[0]); i-- > 0;) revertPatch(patches[i]);
    uninstallHook(g.chatHook);
    uninstallHook(g.enumConstraintHook);
    uninstallHook(g.constraintSetHook);
    uninstallHook(g.overloadHook);
    uninstallHook(g.originHook);
    uninstallHook(g.expansionHook);
    uninstallHook(g.registerHook);
    origRegister = nullptr;
    origEnumConstraint = nullptr;
    origChat = nullptr;
    g.coreInstalled = false;
    g.optionalAttempted = false;
    g.status &= STATUS_LOADED | STATUS_MC_BASE;
}

static bool validateCore() {
    if (!getMinecraftBase()) return false;
    struct Guard { uintptr_t rva; const uint8_t* bytes; std::size_t len; const char* name; } guards[] = {
        {RVA_REGISTER, SIG_REGISTER, sizeof(SIG_REGISTER), "registerCommand"},
        {RVA_EXPANSION, SIG_EXPANSION, sizeof(SIG_EXPANSION), "isExpansionAllowed"},
        {RVA_ORIGIN, SIG_ORIGIN, sizeof(SIG_ORIGIN), "originCanRun"},
        {RVA_OVERLOAD, SIG_OVERLOAD, sizeof(SIG_OVERLOAD), "originCanRunOverloadWithParam"},
        {RVA_CONSTRAINT_SET, SIG_CONSTRAINT_SET, sizeof(SIG_CONSTRAINT_SET), "_matchesEnumConstraintsSet"},
    };
    for (const auto& x : guards) {
        if (!bytesEqual(g.base + x.rva, x.bytes, x.len)) {
            __android_log_print(ANDROID_LOG_ERROR, TAG,
                                "core validation failed: %s prologue mismatch RVA 0x%llx",
                                x.name, static_cast<unsigned long long>(x.rva));
            return false;
        }
    }
    if (!verifyAbilityDispatchSignature()) {
        loge("core validation failed: masked AbilityCommand dispatch signature mismatch");
        return false;
    }
    for (auto& p : patches) {
        if (!p.critical) continue;
        uint8_t current[8]{};
        if (!readBytes(g.base + p.rva, current, p.length)) return false;
        if (std::memcmp(current, p.expected, p.length) != 0 &&
            std::memcmp(current, p.replacement, p.length) != 0) {
            __android_log_print(ANDROID_LOG_ERROR, TAG,
                                "core validation failed: %s unexpected bytes", p.name);
            return false;
        }
    }
    g.status |= STATUS_CORE_VALIDATED;
    return true;
}

static bool installCore() {
    if (g.coreInstalled) {
        for (auto& p : patches) {
            if (!p.critical) continue;
            uint8_t current[8]{};
            if (!readBytes(g.base + p.rva, current, p.length)) return false;
            if (std::memcmp(current, p.replacement, p.length) == 0) continue;
            if (std::memcmp(current, p.expected, p.length) != 0) {
                __android_log_print(ANDROID_LOG_ERROR, TAG,
                                    "core recheck failed: %s has unexpected bytes", p.name);
                return false;
            }
            p.applied = false;
            p.owned = false;
            if (!applyPatch(p)) return false;
            __android_log_print(ANDROID_LOG_WARN, TAG,
                                "core reasserted after original bytes reappeared: %s", p.name);
        }
        return true;
    }
    if (!validateCore()) return false;

    void* orig = nullptr;
    if (!installHook(g.registerHook, RVA_REGISTER, SIG_REGISTER, sizeof(SIG_REGISTER),
                     reinterpret_cast<void*>(&hookRegisterCommand), &orig,
                     "CommandRegistry::registerCommand", true)) goto fail;
    origRegister = reinterpret_cast<RegisterCommandFn>(orig);
    g.status |= STATUS_REGISTER_HOOK;

    if (!installHook(g.expansionHook, RVA_EXPANSION, SIG_EXPANSION, sizeof(SIG_EXPANSION),
                     reinterpret_cast<void*>(&hookExpansionAllowed), nullptr,
                     "CommandSelectorBase::isExpansionAllowed", true)) goto fail;
    g.status |= STATUS_EXPAND_HOOK;

    if (!installHook(g.originHook, RVA_ORIGIN, SIG_ORIGIN, sizeof(SIG_ORIGIN),
                     reinterpret_cast<void*>(&hookOriginCanRun), nullptr,
                     "CommandRegistry::originCanRun", true)) goto fail;
    g.status |= STATUS_ORIGIN_HOOK;

    if (!installHook(g.overloadHook, RVA_OVERLOAD, SIG_OVERLOAD, sizeof(SIG_OVERLOAD),
                     reinterpret_cast<void*>(&hookOriginCanRunOverload), nullptr,
                     "CommandRegistry::originCanRunOverloadWithParam", true)) goto fail;
    g.status |= STATUS_OVERLOAD_HOOK;

    if (!installHook(g.constraintSetHook, RVA_CONSTRAINT_SET, SIG_CONSTRAINT_SET, sizeof(SIG_CONSTRAINT_SET),
                     reinterpret_cast<void*>(&hookMatchesConstraintSet), nullptr,
                     "CommandRegistry::_matchesEnumConstraintsSet", true)) goto fail;
    g.status |= STATUS_CONSTRAINT_HOOK;

    if (!applyPatch(patches[0])) goto fail;
    g.status |= STATUS_GATE_A;
    if (!applyPatch(patches[1])) goto fail;
    g.status |= STATUS_GATE_B;
    if (!applyPatch(patches[2])) goto fail;
    g.status |= STATUS_DISPATCH_GATE;
    if (!applyPatch(patches[3])) goto fail;
    g.status |= STATUS_ABILITY_GATE;

    g.coreInstalled = true;
    logi("CORE READY: cheats-disabled gates + native /ability registration gate installed");
    return true;

fail:
    loge("CORE INSTALL FAILED; rolling back only owned core state");
    rollbackAll();
    return false;
}

static void installOptional() {
    if (g.optionalAttempted || !g.coreInstalled) return;
    g.optionalAttempted = true;
    bool all = true;

    void* orig = nullptr;
    if (bytesEqual(g.base + RVA_ENUM_CONSTRAINT, SIG_ENUM_CONSTRAINT, sizeof(SIG_ENUM_CONSTRAINT)) &&
        installHook(g.enumConstraintHook, RVA_ENUM_CONSTRAINT, SIG_ENUM_CONSTRAINT, sizeof(SIG_ENUM_CONSTRAINT),
                    reinterpret_cast<void*>(&hookEnumConstraints), &orig,
                    "CommandRegistry::addEnumValueConstraints", false)) {
        origEnumConstraint = reinterpret_cast<EnumConstraintFn>(orig);
        g.status |= STATUS_ENUM_HOOK;
    } else {
        all = false;
    }

    orig = nullptr;
    if (bytesEqual(g.base + RVA_CHAT, SIG_CHAT, sizeof(SIG_CHAT)) &&
        installHook(g.chatHook, RVA_CHAT, SIG_CHAT, sizeof(SIG_CHAT),
                    reinterpret_cast<void*>(&hookChatDirty), &orig,
                    "ChatScreenController intellisense", false)) {
        origChat = reinterpret_cast<ChatFn>(orig);
        g.status |= STATUS_CHAT_HOOK;
    } else {
        all = false;
    }

    for (std::size_t i = 4; i < sizeof(patches)/sizeof(patches[0]); ++i) {
        if (!applyPatch(patches[i])) all = false;
    }
    if (all) g.status |= STATUS_OPTIONAL;
    __android_log_print(ANDROID_LOG_INFO, TAG,
                        "optional all-commands/tweaks stage complete: %s",
                        all ? "all verified" : "partial; core remains active");
}

static bool lifecycleLoad(void*, pl::mod::ModContext&) {
    g.status |= STATUS_LOADED;
    logi("load() V1.4.8 1.26.52.03 autocomplete enum flags fix entered");
    if (installCore()) installOptional();
    else logw("load(): core not ready yet; enable() will retry");
    return true;
}

static bool lifecycleEnable(void*, pl::mod::ModContext&) {
    logi("enable() entered");
    if (!installCore()) {
        loge("enable(): FAILED at mandatory core command bypass");
        return false;
    }
    installOptional();
    g.status |= STATUS_ENABLED;
    __android_log_print(ANDROID_LOG_INFO, TAG,
                        "enable(): SUCCESS status=0x%08x base=0x%llx",
                        g.status, static_cast<unsigned long long>(g.base));
    return true;
}

static bool lifecycleDisable(void*, pl::mod::ModContext&) {
    logi("disable(): restoring owned hooks/patches");
    rollbackAll();
    g.status &= ~STATUS_ENABLED;
    return true;
}

static bool lifecycleUnload(void*, pl::mod::ModContext&) {
    logi("unload(): cleanup");
    rollbackAll();
    g = {};
    return true;
}

static int gInstanceAnchor = 0x146;
static const pl::mod::ModRegistration gRegistration = {
    &gInstanceAnchor,
    &lifecycleLoad,
    &lifecycleEnable,
    &lifecycleDisable,
    &lifecycleUnload,
};
} // namespace

CTAC_EXPORT const pl::mod::ModRegistration* PLGetModRegistration() {
    return &gRegistration;
}

CTAC_EXPORT uint32_t CheatlessTweaksAllCommandsStatus() {
    return g.status;
}

CTAC_EXPORT const char* CheatlessTweaksAllCommandsBuildIdentity() {
    return kBuildIdentity;
}
