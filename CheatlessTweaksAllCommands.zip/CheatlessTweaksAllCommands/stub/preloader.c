/* Link-time stub. At runtime LeviLaunchroid provides the real libpreloader.so. */
void* GlossHook(void* target, void* replacement, void** original) {
    (void)target;
    (void)replacement;
    if (original) *original = 0;
    return 0;
}
void GlossHookDelete(void* hook) { (void)hook; }
void* ReadMemory(void* address, void* buffer, unsigned long size, int changeProtection) {
    (void)address;
    (void)buffer;
    (void)size;
    (void)changeProtection;
    return 0;
}
void WriteMemory(void* address, const void* data, unsigned long size, int changeProtection) {
    (void)address;
    (void)data;
    (void)size;
    (void)changeProtection;
}
unsigned long GlossGetLibBias(const char* libraryName) {
    (void)libraryName;
    return 0;
}
unsigned long GlossFindLibMapping(const char* libraryName, int pid, char* pathOut, unsigned long* mappedSizeOut) {
    (void)libraryName;
    (void)pid;
    (void)pathOut;
    (void)mappedSizeOut;
    return 0;
}
